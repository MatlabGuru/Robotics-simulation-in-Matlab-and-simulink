inputs=[input1,input2,output1];
inputs1=inputs';
